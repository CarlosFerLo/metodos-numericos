/* Carlos Fernández Lorán */
double derivar(double x, double h, int ordre, double (*f)(double)) ;
