/* Carlos Fernández Lorán */
double hornernewton (double *dd, double *x, double z, int n) ;
