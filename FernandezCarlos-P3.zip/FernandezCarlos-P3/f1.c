/* Carlos Fernández Lorán */
#include <math.h>

double f (double x) {
    return exp(x) ;
}

double df (double x) {
    return exp(x) ;
}

double ddf (double x) {
    return exp(x) ;
}