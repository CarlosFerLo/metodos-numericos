/* Carlos Fernández Lorán */
void didi(double *x, double *f, int n) ;
