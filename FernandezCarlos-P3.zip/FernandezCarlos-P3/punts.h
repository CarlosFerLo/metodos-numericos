void punts (double *x, double *f, int n) ;
