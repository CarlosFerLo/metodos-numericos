/* Carlos Fernández Lorán */
double horner(double *a, double z, int n) ;
