/* Carlos Fernández Lorán */
double f (double x) ;
double df (double x) ;
double ddf (double x) ;