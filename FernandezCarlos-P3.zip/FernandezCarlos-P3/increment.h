/* Carlos Fernández Lorán */
double increment (int p, double q, double y, double z) ;
