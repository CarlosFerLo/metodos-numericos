/* Carlos Fernández Lorán */
double gauss(double** a, double* x, double* b, int n, double tol) ;
