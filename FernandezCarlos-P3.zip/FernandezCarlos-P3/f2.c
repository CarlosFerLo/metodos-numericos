/* Carlos Fernández Lorán */
#include <math.h>

double f (double x) {
    return sin(x) ;
}

double df (double x) {
    return cos(x) ;
}

double ddf (double x) {
    return - sin (x) ;
}